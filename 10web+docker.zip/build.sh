#! /usr/bin/env bash

docker pull nickistre/centos-lamp:latest
docker pull eboraas/apache-php:latest
cd 01/
docker build -t bugku:01 .
cd ../02/
docker build -t bugku:02 .
cd ../03/
docker build -t bugku:03 .
cd ../04/
docker build -t bugku:04 .
cd ../05/
docker build -t bugku:05 .
cd ../06/
docker build -t bugku:06 .
cd ../07/
docker build -t bugku:07 .
cd ../08/
docker build -t bugku:08 .
cd ../09/
docker build -t bugku:09 .
cd ../10/
docker build -t bugku:10 .
