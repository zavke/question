#! /usr/bin/env bash

docker run -i -d -p 1001:80 bugku:01
docker run -i -d -p 1002:80 bugku:02
docker run -i -d -p 1003:80 bugku:03
docker run -i -d -p 1004:80 bugku:04
docker run -i -d -p 1005:80 bugku:05
docker run -i -d -p 1006:80 bugku:06
docker run -i -d -p 1007:80 bugku:07
docker run -i -d -p 1008:80 bugku:08
docker run -i -d -p 1009:80 bugku:09
docker run -i -d -p 1010:80 bugku:10
