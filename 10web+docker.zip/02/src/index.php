<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<center>
快打开它，你要的宝藏就再里面！<br/>
<img src="baozang.jpg"/>
</center>
</body>
</html>

