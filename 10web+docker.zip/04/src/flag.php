<?php 
$myFlag='flag{num_test_administrator}';
?>