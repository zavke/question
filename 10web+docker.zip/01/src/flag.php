<?php 
header('Flag: '.base64_encode("myCTF{sdsxdwefvsdfs}")); //修改 X-Powered-By信息
header('location:404.php');
?>