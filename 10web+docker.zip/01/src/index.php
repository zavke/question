<html>
<head>
<title>flag在这里</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<a href="flag.php">flag在这里</a>
</body>
</html>